<?php
include "header.php";
include "top.php";
?>

	
	<section>
		<div class="container">
			<div class="row">
			
				<div class="col-md-12 col-lg-8">
				<?php 
					include "section1.php";
					// include "section2.php";
				?>
				</div>
				
				<div class="d-none d-md-block d-lg-none col-md-3"></div>
				<?php
                  include "sidebar.php";
				?>
				
			</div>
		</div>
	</section>




<?php
include "footer.php";
?>